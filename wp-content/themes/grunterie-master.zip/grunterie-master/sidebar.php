<aside id="sidebar" class="small-12 large-4 columns">
	<?php dynamic_sidebar("Sidebar"); ?>
</aside><!-- /#sidebar -->